#include <stdio.h>
void main()
{
     printf("Hello!This is my first program in Ubuntu 11.10\n");/* Do something more if you want */
}
